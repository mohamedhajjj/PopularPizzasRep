//
//  ViewController.swift
//  PopularPizzas
//
//  Created by Mohamed Taieb on 6/14/16.
//  Copyright © 2016 Mohamed Taieb. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!
    
    let pizzaManager = PizzaJSONManager.sharedInstance as PizzaJSONManager
    var topOrders : [PizzaOrder] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        //Parse the pizza.json file
        pizzaManager.parsePizzaJSON()
        //Get the top 20 orders from the list of order-topping combinations
        topOrders = pizzaManager.getTopOrders(20)
        
        //Setup the tableView
        let cellNib = UINib(nibName: PizzaOrderCell.cellNibName(), bundle: nil)
        tableView.registerNib(cellNib, forCellReuseIdentifier: PizzaOrderCell.reuseIdentifier())
        tableView.delegate = self
        tableView.dataSource = self
        //Setup dynamic cell height in case the toppings list requires multiple lines
        tableView.rowHeight = UITableViewAutomaticDimension
        tableView.estimatedRowHeight = 100.0
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return topOrders.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier(PizzaOrderCell.reuseIdentifier(), forIndexPath: indexPath) as! PizzaOrderCell
        
        //Compile the list of toppings
        var toppingList = "Toppings: "
        let pizzaOrder = topOrders[indexPath.row]
        let maxToppingIndex = (pizzaOrder.toppingsArray?.count)!-1
        for (index, topping) in (pizzaOrder.toppingsArray?.enumerate())! {
            if (index == maxToppingIndex) {
                toppingList += topping
            } else {
                toppingList += topping + ", "
            }
        }//Set the toppingsListLabel
        cell.toppingsListLabel.text = toppingList
        //Set the Ranking and # Orders labels
        cell.topIndexLabel.text = "Rank: " + String(indexPath.row+1)
        cell.numberOfOrdersLabel.text = "# of Orders: " + String(pizzaOrder.orderCount)
        return cell
    }
}

