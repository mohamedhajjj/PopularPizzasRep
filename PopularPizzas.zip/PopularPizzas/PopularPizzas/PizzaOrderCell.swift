//
//  PizzaOrderCell.swift
//  PopularPizzas
//
//  Created by Mohamed Taieb on 6/14/16.
//  Copyright © 2016 Mohamed Taieb. All rights reserved.
//

import UIKit

class PizzaOrderCell: UITableViewCell {

    @IBOutlet weak var topIndexLabel: UILabel!
    @IBOutlet weak var numberOfOrdersLabel: UILabel!
    @IBOutlet weak var toppingsListLabel: UILabel!
    
    override func prepareForReuse() {
        super.prepareForReuse()
        topIndexLabel.text = ""
        numberOfOrdersLabel.text = ""
        toppingsListLabel.text = ""
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    class func reuseIdentifier() -> String {
        return "PizzaOrderCell"
    }
    
    class func cellNibName() -> String {
        return "PizzaOrderCell"
    }
    
}
