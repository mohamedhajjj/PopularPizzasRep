//
//  PizzaJSONManager.swift
//  PopularPizzas
//
//  Created by Mohamed Taieb on 6/14/16.
//  Copyright © 2016 Mohamed Taieb. All rights reserved.
//

import UIKit

class PizzaOrder: NSObject {
    var toppingsArray : [String]?
    var orderCount = 0
}

class PizzaJSONManager: NSObject {
    
    //Set the manager to be a singleton
    static let sharedInstance = PizzaJSONManager()
    private override init() {}
    
    var pizzaList : [PizzaOrder] = []
    let orderNotFound = -1
    
    func parsePizzaJSON() {
        //Clear out the existing list
        pizzaList.removeAll()
        if let path = NSBundle.mainBundle().pathForResource("pizzas", ofType: "json") {
            if let jsonData = NSData(contentsOfFile: path) {
                let jsonRootArray : [NSDictionary]?
                do {
                    jsonRootArray = try NSJSONSerialization.JSONObjectWithData(jsonData, options: NSJSONReadingOptions.MutableContainers) as? [NSDictionary]
                    //For each of the pizza dictionaries inside our array
                    for jsonPizzaDict in jsonRootArray! {
                        //Grab the array of toppings
                        let jsonToppingsArray : [String] = jsonPizzaDict["toppings"] as! [String]
                        //Add the order into the list or increment the order count if order already found
                        addOrderToList(jsonToppingsArray)
                    }
                } catch {
                        //something went wrong
                }
            }
            
        }
    }
    
    func indexOfOrder(toppingsArray : [String]) -> Int {
        if pizzaList.count == 0 { return orderNotFound }
        //For each order in the existing pizzaList compare the orders and determine if it matches
        for order in pizzaList {
            //Topping count doesn't match this order, go to next order
            if toppingsArray.count != order.toppingsArray?.count { continue }
            
            var doesOrderMatch = true
            for topping in toppingsArray {
                //For each topping check if it exists in the order
                if (order.toppingsArray?.contains(topping) == false) {
                    //Topping wasn't found in the toppings for the order go to next order
                    doesOrderMatch = false
                    break
                }
            }
            if (doesOrderMatch) {
                //Toppings list matches the order, return the index
                return pizzaList.indexOf(order)!
            }
        }
        
        
        return orderNotFound
    }
    
    func addOrderToList(toppingsArray : [String]) {
        let orderIndex = indexOfOrder(toppingsArray)
        if orderIndex == orderNotFound {
            //Order doesn't exist so create and add it
            let pizzaOrder = PizzaOrder()
            pizzaOrder.toppingsArray = toppingsArray
            pizzaOrder.orderCount = 1
            //Add the order into the list
            pizzaList.append(pizzaOrder)
        } else {
            //Order already exists, get an instance of that order and increment the count
            let order = pizzaList[orderIndex] as PizzaOrder
            order.orderCount += 1
        }
    }
    
    func getTopOrders(topXOrders : Int) -> [PizzaOrder] {
        var sortedArray : [PizzaOrder] = []
        
        for order in pizzaList {
            if (sortedArray.count == 0) {
                sortedArray.append(order)
                continue //Go to next order
            }
            //Sort the array of orders by the orderCount
            var insertedOrder = false
            for (index, element) in sortedArray.enumerate() {
                if (order.orderCount > element.orderCount) {
                    sortedArray.insert(order, atIndex: index)
                    insertedOrder = true
                    break
                }
            }
            if !insertedOrder {
                //Did not find an order with less count, add to list
                sortedArray.append(order)
            }
        }
        //Return the top X orders
        let topArray = Array(sortedArray[0..<topXOrders])
        return topArray
    }
    
}
